/*
 * SPDX-FileCopyrightText: 2026 Pagefault Games
 * SPDX-FileContributor: Bertie690
 *
 * SPDX-License-Identifier: AGPL-3.0-only
 *
 * This script wraps Vitest's test runner with node's built-in V8 profiler.
 * Any extra CLI arguments are passed directly to `vitest run`.
 */

import { defaultCommanderHelpArgs } from "#script-utils/arguments";
import { copyFile, glob, mkdir, mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, join } from "node:path";
import { Command } from "@commander-js/extra-typings";
import chalk from "chalk";
import { parseCLI, startVitest } from "vitest/node";

const version = "1.0.0";

console.log(chalk.hex("#ffa500")(`📈 Test Profiler - v${version}\n`));

const testProfile = new Command("pnpm test:profile")
  .description("Run Vitest with Node's V8 profiler and generate processed profiling output.")
  .helpOption("-h, --help", "Show this help message.")
  .version(version, "-v, --version", "Show the version number.")
  .option("-o, --output <path>", "Directory to which V8 profiler output will be written.", "./temp/vitest-profile")
  .option("-c, --cpu", "Enable CPU profiling.", true)
  .option("--no-cpu", "Disable CPU profiling.")
  .option("-m, --memory", "Enable memory profiling.", true)
  .option("--no-memory", "Disable memory profiling.")
  .option("--clean", "Whether to clean the output directory before writing new profiles.", false)
  .argument("<vitest-args...>", "Arguments and flags to pass directly to Vitest.")
  .configureHelp(defaultCommanderHelpArgs)
  // only show help on argument parsing errors, not on test failures
  .showHelpAfterError(true)
  .passThroughOptions()
  .parse();

const { output, cpu, memory, clean } = testProfile.opts();
/** The directory to write profiling outputs to. (May or may not be the final destination.) */
let outputDir = output;

if (!cpu && !memory) {
  testProfile.error("Cannot disable both CPU and memory profiling!");
}

testProfile.showHelpAfterError(false);

/**
 * Run the `test:profile` CLI.
 */
async function main(): Promise<void> {
  if (clean) {
    await rm(outputDir, { recursive: true, force: true });
    await mkdir(outputDir, { recursive: true });
  } else {
    await mkdir(output, { recursive: true });
    // output profile files to a temp directory before moving them to the desired location, ensuring both exist
    outputDir = await mkdtemp(join(tmpdir(), "vitest-profile-"), { encoding: "utf-8" });
  }

  console.log(chalk.grey("Running Vitest with V8 profiler..."));

  const execArgv: string[] = [];
  if (cpu) {
    execArgv.push(
      "--cpu-prof",
      `--cpu-prof-name=vitest-cpu-profile.${Date.now()}.cpuprofile`,
      `--cpu-prof-dir=${outputDir}`,
    );
  }
  if (memory) {
    execArgv.push(
      "--heap-prof",
      `--heap-prof-name=vitest-heap-profile.${Date.now()}.heapprofile`,
      `--heap-prof-dir=${outputDir}`,
    );
  }

  const { filter, options } = parseCLI(["vitest", "run", ...testProfile.args]);

  const vitest = await startVitest("test", filter, {
    ...options,
    fileParallelism: false,
    // swap to threads to work around vitest-dev/vitest#9907;
    // the lack of SIGTERM events on windows would otherwise prevent profiling data from being written
    pool: "threads",
    execArgv,
  });
  // NB: This sets `process.exitCode` to a non-zero value if it fails
  await vitest.close();
  if (process.exitCode) {
    return;
  }

  const [cpuProfile, memoryProfile] = await Promise.all([
    (await glob(join(outputDir, "*.cpuprofile")).next()).value,
    (await glob(join(outputDir, "*.heapprofile")).next()).value,
  ]);
  if (!cpuProfile && !memoryProfile) {
    console.error(chalk.red.bold("No CPU or memory profile found!"));
    process.exitCode = 1;
    return;
  }

  if (!clean) {
    await Promise.all([
      cpuProfile && copyFile(cpuProfile, join(output, basename(cpuProfile))),
      memoryProfile && copyFile(memoryProfile, join(output, basename(memoryProfile))),
    ]);
  }

  if (cpuProfile) {
    console.log("Wrote processed CPU profile to:", chalk.bold.blue(cpuProfile));
  }
  if (memoryProfile) {
    console.log("Wrote processed memory profile to:", chalk.bold.blue(memoryProfile));
  }

  console.log(chalk.green.bold("Profiling complete!"));
}

await main();
