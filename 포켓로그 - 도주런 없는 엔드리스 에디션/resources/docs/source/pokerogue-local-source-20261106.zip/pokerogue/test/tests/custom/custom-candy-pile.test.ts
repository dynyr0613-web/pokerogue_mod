import { modifierTypes } from "#data/data-lists";
import { getLevelTotalExp } from "#data/exp";
import { AbilityId } from "#enums/ability-id";
import { Button } from "#enums/buttons";
import { ModifierPoolType } from "#enums/modifier-pool-type";
import { ModifierTier } from "#enums/modifier-tier";
import { MoveId } from "#enums/move-id";
import { ShopCursorTarget } from "#enums/shop-cursor-target";
import { SpeciesId } from "#enums/species-id";
import { UiMode } from "#enums/ui-mode";
import type { PlayerPokemon } from "#field/pokemon";
import { LearnMovePhase } from "#phases/learn-move-phase";
import { GameManager } from "#test/framework/game-manager";
import { ModifierSelectUiHandler } from "#ui/modifier-select-ui-handler";
import { PartyUiHandler } from "#ui/party-ui-handler";
import { getModifierPoolForType } from "#utils/modifier-utils";
import Phaser from "phaser";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

describe("Custom consumables - Candy Pile (사탕더미)", () => {
  let phaserGame: Phaser.Game;
  let game: GameManager;
  /** [species at that moment, move] for every move a level-up or evolution offered */
  let offered: [SpeciesId, MoveId][];

  beforeAll(() => {
    phaserGame = new Phaser.Game({ type: Phaser.HEADLESS });
  });

  beforeEach(() => {
    game = new GameManager(phaserGame);
    game.override
      .battleStyle("single")
      .startingLevel(20)
      .startingWave(1)
      .itemRewards([{ name: "CANDY_PILE" }])
      .enemySpecies(SpeciesId.MAGIKARP)
      .enemyLevel(1)
      .enemyAbility(AbilityId.BALL_FETCH)
      .enemyMoveset(MoveId.SPLASH)
      .ability(AbilityId.BALL_FETCH)
      .moveset([MoveId.SPLASH]);
    // Record offered moves instead of opening the learn-move menus
    offered = [];
    vi.spyOn(LearnMovePhase.prototype, "start").mockImplementation(function (this: LearnMovePhase) {
      offered.push([this.getPokemon().species.speciesId, (this as unknown as { moveId: MoveId }).moveId]);
      this.end();
    });
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  function addCandyJars(count: number): void {
    for (let i = 0; i < count; i++) {
      game.scene.addModifier(modifierTypes.CANDY_JAR().withIdFromFunc(modifierTypes.CANDY_JAR).newModifier()!);
    }
  }

  /**
   * Win the wave, take the Candy Pile from the reward screen, give it to party slot `slot` and run every phase it
   * queues. Returns each party member's level and friendship just before the pick.
   */
  async function pickPileFor(slot: number): Promise<{ level: number; friendship: number }[]> {
    let before: { level: number; friendship: number }[] = [];
    game.move.select(MoveId.SPLASH);
    await game.doKillOpponents();
    await game.phaseInterceptor.to("SelectModifierPhase", false);
    // wait for the reward screen to take input (its tutorial check is async)
    game.onNextPrompt(
      "SelectModifierPhase",
      UiMode.MODIFIER_SELECT,
      () => {
        before = game.scene.getPlayerParty().map(p => ({ level: p.level, friendship: p.friendship }));
        const handler = game.scene.ui.getHandler() as ModifierSelectUiHandler;
        expect(handler).toBeInstanceOf(ModifierSelectUiHandler);
        handler.setRowCursor(ShopCursorTarget.REWARDS);
        handler.setCursor(0);
        handler.processInput(Button.ACTION);
      },
      undefined,
      true,
    );
    game.onNextPrompt("SelectModifierPhase", UiMode.PARTY, () => {
      const handler = game.scene.ui.getHandler() as PartyUiHandler;
      expect(handler).toBeInstanceOf(PartyUiHandler);
      handler.setCursor(slot);
      handler.processInput(Button.ACTION); // open its options
      handler.processInput(Button.ACTION); // Apply
    });
    await game.phaseInterceptor.to("NewBattlePhase", false);
    return before;
  }

  function setLevel(pokemon: PlayerPokemon, level: number): void {
    pokemon.level = level;
    pokemon.exp = getLevelTotalExp(level, pokemon.species.growthRate);
  }

  it("gives the chosen Pokémon 7 candies and the rest 2, each worth 1 level + 1 per Candy Jar, with candy friendship", async () => {
    await game.classicMode.startBattle(SpeciesId.SNORLAX, SpeciesId.LAPRAS, SpeciesId.TAUROS);
    const party = game.scene.getPlayerParty();
    addCandyJars(2);
    for (const p of party) {
      p.friendship = 0;
    }

    const before = await pickPileFor(2);

    // 2 jars: 3 levels per candy; Rare Candy friendship is 6 per candy
    expect(party.map((p, i) => p.level - before[i].level)).toEqual([6, 6, 21]);
    expect(party.map((p, i) => p.friendship - before[i].friendship)).toEqual([12, 12, 42]);
    for (const p of party) {
      expect(p.exp).toBe(getLevelTotalExp(p.level, p.species.growthRate));
    }
  });

  it("goes through every evolution on the way, offering moves from the species at each point (Caterpie -> Butterfree)", async () => {
    game.override.startingLevel(5);
    await game.classicMode.startBattle(SpeciesId.CATERPIE);
    const caterpie = game.scene.getPlayerParty()[0];
    expect(caterpie.level).toBe(5);

    await pickPileFor(0);

    // Rare Candies: 6, 7 (Metapod), 8, 9, 10 (Butterfree); Rarer Candies: 11 (Confusion), 12
    expect(caterpie.species.speciesId).toBe(SpeciesId.BUTTERFREE);
    expect(caterpie.level).toBe(12);
    expect(offered).toContainEqual([SpeciesId.BUTTERFREE, MoveId.CONFUSION]);
    expect(offered).not.toContainEqual([SpeciesId.CATERPIE, MoveId.BUG_BITE]);
  });

  it("evolves twice inside long Candy Jar jumps (Charmander L14 with 3 jars -> Charizard L42)", async () => {
    game.override.startingLevel(14);
    await game.classicMode.startBattle(SpeciesId.CHARMANDER);
    const charmander = game.scene.getPlayerParty()[0];
    addCandyJars(3);

    await pickPileFor(0);

    // 4 levels per candy: 18 (Charmeleon), 22, 26, 30, 34, then 38 (Charizard), 42
    expect(charmander.level).toBe(42);
    expect(charmander.species.speciesId).toBe(SpeciesId.CHARIZARD);
  });

  it("lets the Rarer Candies evolve the other party members too (Caterpie L8 -> Butterfree L10)", async () => {
    await game.classicMode.startBattle(SpeciesId.SNORLAX, SpeciesId.CATERPIE);
    const [snorlax, caterpie] = game.scene.getPlayerParty();
    setLevel(caterpie, 8);

    const before = await pickPileFor(0);

    expect(snorlax.level - before[0].level).toBe(7);
    expect(caterpie.level).toBe(10);
    expect(caterpie.species.speciesId).toBe(SpeciesId.BUTTERFREE);
  });

  it("gives a Shedinja that appears partway the Rarer Candies still to come", async () => {
    game.override.startingLevel(15);
    await game.classicMode.startBattle(SpeciesId.NINCADA, SpeciesId.SNORLAX);

    await pickPileFor(0);

    // Rare Candies: Nincada 16-20, evolving into Ninjask + Shedinja at 20; both Rarer Candies then reach all three
    const party = game.scene.getPlayerParty();
    expect(party.map(p => [p.species.speciesId, p.level])).toEqual([
      [SpeciesId.NINJASK, 22],
      [SpeciesId.SNORLAX, 17],
      [SpeciesId.SHEDINJA, 22],
    ]);
  });

  it("also levels fainted party members, like Rarer Candy", async () => {
    await game.classicMode.startBattle(SpeciesId.SNORLAX, SpeciesId.LAPRAS);
    const party = game.scene.getPlayerParty();
    party[1].hp = 0;

    const before = await pickPileFor(0);

    expect(party.map((p, i) => p.level - before[i].level)).toEqual([7, 2]);
  });

  it("describes the levels with the Candy Jars counted", async () => {
    await game.classicMode.startBattle(SpeciesId.SNORLAX);
    const type = modifierTypes.CANDY_PILE().withIdFromFunc(modifierTypes.CANDY_PILE);
    expect(type.name).toBe("Candy Pile");
    expect(type.getDescription()).toBe(
      "Uses 5 Rare Candies and 2 Rarer Candies at once: the chosen Pokémon gains 7 levels and the rest of the party 2.",
    );
    addCandyJars(1);
    expect(type.getDescription()).toContain("gains 14 levels and the rest of the party 4.");
  });

  it("sits in the ROGUE tier of the player pool at weight 4, and nowhere else", () => {
    const pool = getModifierPoolForType(ModifierPoolType.PLAYER);
    const rogue = pool[ModifierTier.ROGUE].find(w => w.modifierType.id === "CANDY_PILE");
    expect(rogue).toBeDefined();
    expect(rogue!.weight).toBe(4);
    expect(rogue!.modifierType.tier).toBe(ModifierTier.ROGUE);
    for (const tier of [ModifierTier.COMMON, ModifierTier.GREAT, ModifierTier.ULTRA, ModifierTier.MASTER]) {
      expect(pool[tier].some(w => w.modifierType.id === "CANDY_PILE")).toBe(false);
    }
  });
});
