import { audioManager } from "#app/global-audio-manager";
import { globalScene } from "#app/global-scene";
import { speciesDataRegistry } from "#app/global-species-data-registry";
import { modifierTypes } from "#data/data-lists";
import { BattlerIndex } from "#enums/battler-index";
import { BattlerTagType } from "#enums/battler-tag-type";
import type { BerryType } from "#enums/berry-type";
import { MoveId } from "#enums/move-id";
import { MoveUseMode } from "#enums/move-use-mode";
import { MysteryEncounterOptionMode } from "#enums/mystery-encounter-option-mode";
import { MysteryEncounterTier } from "#enums/mystery-encounter-tier";
import { MysteryEncounterType } from "#enums/mystery-encounter-type";
import { PokeballType } from "#enums/pokeball";
import { SpeciesId } from "#enums/species-id";
import { Stat } from "#enums/stat";
import { TrainerSlot } from "#enums/trainer-slot";
import type { PlayerPokemon, Pokemon } from "#field/pokemon";
import { EnemyPokemon } from "#field/pokemon";
import type { PokemonHeldItemModifier } from "#modifiers/modifier";
import { BerryModifier, PokemonInstantReviveModifier } from "#modifiers/modifier";
import type { BerryModifierType, PokemonHeldItemModifierType } from "#modifiers/modifier-type";
import { PokemonMove } from "#moves/pokemon-move";
import { queueEncounterMessage } from "#mystery-encounters/encounter-dialogue-utils";
import type { EnemyPartyConfig } from "#mystery-encounters/encounter-phase-utils";
import {
  generateModifierType,
  initBattleWithEnemyConfig,
  leaveEncounterWithoutBattle,
  setEncounterRewards,
  transitionMysteryEncounterIntroVisuals,
} from "#mystery-encounters/encounter-phase-utils";
import { catchPokemon, getHighestLevelPlayerPokemon } from "#mystery-encounters/encounter-pokemon-utils";
import type { MysteryEncounter } from "#mystery-encounters/mystery-encounter";
import { MysteryEncounterBuilder } from "#mystery-encounters/mystery-encounter";
import { MysteryEncounterOptionBuilder } from "#mystery-encounters/mystery-encounter-option";
import { PersistentModifierRequirement } from "#mystery-encounters/mystery-encounter-requirements";
import type { HeldModifierConfig } from "#types/held-modifier-config";
import { randInt } from "#utils/common";
import { groupStatChange } from "#utils/stat-change";
import i18next from "i18next";
import Phaser from "phaser";

/** the i18n namespace for this encounter */
const namespace = "mysteryEncounters/absoluteAvarice";

/**
 * Absolute Avarice encounter.
 * @see {@link https://github.com/pagefaultgames/pokerogue/issues/3805 | GitHub Issue #3805}
 * @see For biome requirements check {@linkcode mysteryEncountersByBiome}
 */
export const AbsoluteAvariceEncounter: MysteryEncounter = MysteryEncounterBuilder.withEncounterType(
  MysteryEncounterType.ABSOLUTE_AVARICE,
)
  .withEncounterTier(MysteryEncounterTier.GREAT)
  .withSceneWaveRangeRequirement(20, 180)
  .withSceneRequirement(new PersistentModifierRequirement("BerryModifier", 6)) // Must have at least 6 berries to spawn
  .withFleeAllowed(false)
  .withIntroSpriteConfigs([
    {
      // This sprite has the shadow
      spriteKey: "",
      fileRoot: "",
      species: SpeciesId.GREEDENT,
      hasShadow: true,
      alpha: 0.001,
      repeat: true,
      x: -5,
    },
    {
      spriteKey: "",
      fileRoot: "",
      species: SpeciesId.GREEDENT,
      hasShadow: false,
      repeat: true,
      x: -5,
    },
    {
      spriteKey: "lum_berry",
      fileRoot: "items",
      isItem: true,
      x: 7,
      y: -14,
      hidden: true,
      disableAnimation: true,
    },
    {
      spriteKey: "salac_berry",
      fileRoot: "items",
      isItem: true,
      x: 2,
      y: 4,
      hidden: true,
      disableAnimation: true,
    },
    {
      spriteKey: "lansat_berry",
      fileRoot: "items",
      isItem: true,
      x: 32,
      y: 5,
      hidden: true,
      disableAnimation: true,
    },
    {
      spriteKey: "liechi_berry",
      fileRoot: "items",
      isItem: true,
      x: 6,
      y: -5,
      hidden: true,
      disableAnimation: true,
    },
    {
      spriteKey: "sitrus_berry",
      fileRoot: "items",
      isItem: true,
      x: 7,
      y: 8,
      hidden: true,
      disableAnimation: true,
    },
    {
      spriteKey: "enigma_berry",
      fileRoot: "items",
      isItem: true,
      x: 26,
      y: -4,
      hidden: true,
      disableAnimation: true,
    },
    {
      spriteKey: "leppa_berry",
      fileRoot: "items",
      isItem: true,
      x: 16,
      y: -27,
      hidden: true,
      disableAnimation: true,
    },
    {
      spriteKey: "petaya_berry",
      fileRoot: "items",
      isItem: true,
      x: 30,
      y: -17,
      hidden: true,
      disableAnimation: true,
    },
    {
      spriteKey: "ganlon_berry",
      fileRoot: "items",
      isItem: true,
      x: 16,
      y: -11,
      hidden: true,
      disableAnimation: true,
    },
    {
      spriteKey: "apicot_berry",
      fileRoot: "items",
      isItem: true,
      x: 14,
      y: -2,
      hidden: true,
      disableAnimation: true,
    },
    {
      spriteKey: "starf_berry",
      fileRoot: "items",
      isItem: true,
      x: 18,
      y: 9,
      hidden: true,
      disableAnimation: true,
    },
  ])
  .withHideWildIntroMessage(true)
  .withAutoHideIntroVisuals(false)
  .withIntroDialogue([
    {
      text: `${namespace}:intro`,
    },
  ])
  .setLocalizationKey(`${namespace}`)
  .withTitle(`${namespace}:title`)
  .withDescription(`${namespace}:description`)
  .withQuery(`${namespace}:query`)
  .withOnInit(() => {
    const encounter = globalScene.currentBattle.mysteryEncounter!;

    globalScene
      .loadSe("PRSFX- Bug Bite", "battle_anims", "PRSFX- Bug Bite.wav")
      .loadSe("Follow Me", "battle_anims", "Follow Me.wav");

    // Get all player berry items, remove from party, and store reference
    const berryItems = globalScene.findModifiers(m => m instanceof BerryModifier) as BerryModifier[];

    // Sort berries by party member ID to more easily re-add later if necessary
    const berryItemsMap = new Map<number, BerryModifier[]>();
    globalScene.getPlayerParty().forEach(pokemon => {
      const pokemonBerries = berryItems.filter(b => b.pokemonId === pokemon.id);
      if (pokemonBerries?.length > 0) {
        berryItemsMap.set(pokemon.id, pokemonBerries);
      }
    });

    encounter.misc = { berryItemsMap };

    // Generates copies of the stolen berries to put on the Greedent
    // Local fork: one config per berry type with a stack count instead of one per berry, since Endless allows
    // 99 berries per type per Pokemon. The types keep the order they were first stolen in.
    const stolenByType = new Map<BerryType, { berryMod: BerryModifier; count: number }>();
    berryItems.forEach(berryMod => {
      const stolen = stolenByType.get(berryMod.berryType);
      if (stolen) {
        stolen.count += berryMod.stackCount;
      } else {
        stolenByType.set(berryMod.berryType, { berryMod, count: berryMod.stackCount });
      }
    });
    const bossModifierConfigs: HeldModifierConfig[] = [];
    stolenByType.forEach(({ berryMod, count }, berryType) => {
      const modifierType = generateModifierType(modifierTypes.BERRY, [berryType]) as PokemonHeldItemModifierType;
      // Overflow berries will be "lost" on the boss, but it's un-catchable anyway
      bossModifierConfigs.push({ modifier: modifierType, stackCount: Math.min(count, getBossBerryCap(berryMod)) });
    });

    // Do NOT remove the real berries yet or else it will be persisted in the session data

    // +1 SpDef below wave 50, SpDef and Speed otherwise
    const statChangesForBattle: (Stat.ATK | Stat.DEF | Stat.SPATK | Stat.SPDEF | Stat.SPD | Stat.ACC | Stat.EVA)[] =
      globalScene.currentBattle.waveIndex < 50 ? [Stat.SPDEF] : [Stat.SPDEF, Stat.SPD];

    // Calculate boss mon
    const config: EnemyPartyConfig = {
      levelAdditiveModifier: 1,
      pokemonConfigs: [
        {
          species: speciesDataRegistry.getSpecies(SpeciesId.GREEDENT),
          isBoss: true,
          bossSegments: 3,
          shiny: false, // Shiny lock because of consistency issues between the different options
          moveSet: [MoveId.THRASH, MoveId.CRUNCH, MoveId.BODY_PRESS, MoveId.SLACK_OFF],
          modifierConfigs: bossModifierConfigs,
          tags: [BattlerTagType.MYSTERY_ENCOUNTER_POST_SUMMON],
          mysteryEncounterBattleEffects: (pokemon: Pokemon) => {
            queueEncounterMessage(`${namespace}:option.1.bossEnraged`);
            globalScene.phaseManager.unshiftNew("StatStageChangePhase", {
              battlerIndex: pokemon.getBattlerIndex(),
              changes: groupStatChange(statChangesForBattle, 1),
              sourcePokemon: pokemon,
            });
          },
        },
      ],
    };

    encounter.enemyPartyConfigs = [config];
    encounter.setDialogueToken("greedentName", speciesDataRegistry.getSpecies(SpeciesId.GREEDENT).getName());

    return true;
  })
  .withOnVisualsStart(() => {
    doGreedentSpriteSteal();
    doBerrySpritePile();

    // Remove the berries from the party
    // Session has been safely saved at this point, so data won't be lost
    const berryItems = globalScene.findModifiers(m => m instanceof BerryModifier) as BerryModifier[];
    berryItems.forEach(berryMod => {
      globalScene.removeModifier(berryMod);
    });

    globalScene.updateModifiers(true);

    return true;
  })
  .withOption(
    MysteryEncounterOptionBuilder.newOptionWithMode(MysteryEncounterOptionMode.DEFAULT)
      .withDialogue({
        buttonLabel: `${namespace}:option.1.label`,
        buttonTooltip: `${namespace}:option.1.tooltip`,
        selected: [
          {
            text: `${namespace}:option.1.selected`,
          },
        ],
      })
      .withOptionPhase(async () => {
        // Pick battle
        const encounter = globalScene.currentBattle.mysteryEncounter!;

        // Provides 1x Reviver Seed to each party member at end of battle
        const revSeed = generateModifierType(modifierTypes.REVIVER_SEED);
        encounter.setDialogueToken(
          "foodReward",
          revSeed?.name ?? i18next.t("modifierType:ModifierType.REVIVER_SEED.name"),
        );
        const givePartyPokemonReviverSeeds = () => {
          const party = globalScene.getPlayerParty();
          party.forEach(p => {
            const heldItems = p.getHeldItems();
            if (revSeed && !heldItems.some(item => item instanceof PokemonInstantReviveModifier)) {
              const seedModifier = revSeed.newModifier(p);
              globalScene.addModifier(seedModifier, false, false, false, true);
            }
          });
          queueEncounterMessage(`${namespace}:option.1.foodStash`);
        };

        setEncounterRewards({ fillRemaining: true }, undefined, givePartyPokemonReviverSeeds);
        encounter.startOfBattleEffects.push({
          sourceBattlerIndex: BattlerIndex.ENEMY,
          targets: [BattlerIndex.ENEMY],
          move: new PokemonMove(MoveId.STUFF_CHEEKS),
          useMode: MoveUseMode.IGNORE_PP,
        });

        await transitionMysteryEncounterIntroVisuals(true, true, 500);
        await initBattleWithEnemyConfig(encounter.enemyPartyConfigs[0]);
      })
      .build(),
  )
  .withOption(
    MysteryEncounterOptionBuilder.newOptionWithMode(MysteryEncounterOptionMode.DEFAULT)
      .withDialogue({
        buttonLabel: `${namespace}:option.2.label`,
        buttonTooltip: `${namespace}:option.2.tooltip`,
        selected: [
          {
            text: `${namespace}:option.2.selected`,
          },
        ],
      })
      .withOptionPhase(async () => {
        const encounter = globalScene.currentBattle.mysteryEncounter!;
        const berryMap = encounter.misc.berryItemsMap;

        // Returns 2/5 of the berries stolen to each Pokemon
        const party = globalScene.getPlayerParty();
        party.forEach(pokemon => {
          const stolenBerries: BerryModifier[] = berryMap.get(pokemon.id);
          const berryTypesAsArray: BerryType[] = [];
          stolenBerries?.forEach(bMod => berryTypesAsArray.push(...new Array(bMod.stackCount).fill(bMod.berryType)));
          const returnedBerryCount = Math.floor(((berryTypesAsArray.length ?? 0) * 2) / 5);

          if (returnedBerryCount > 0) {
            returnBerriesToPokemon(pokemon, drawReturnedBerries(berryTypesAsArray, returnedBerryCount));
          }
        });
        // The returned berries were added without updates; refresh the party and the modifier bar once
        await globalScene.updateModifiers(true);

        await transitionMysteryEncounterIntroVisuals(true, true, 500);
        leaveEncounterWithoutBattle(true);
      })
      .build(),
  )
  .withOption(
    MysteryEncounterOptionBuilder.newOptionWithMode(MysteryEncounterOptionMode.DEFAULT)
      .withDialogue({
        buttonLabel: `${namespace}:option.3.label`,
        buttonTooltip: `${namespace}:option.3.tooltip`,
        selected: [
          {
            text: `${namespace}:option.3.selected`,
          },
        ],
      })
      .withPreOptionPhase(async () => {
        // Animate berries being eaten
        doGreedentEatBerries();
        doBerrySpritePile(true);
        return true;
      })
      .withOptionPhase(async () => {
        // Let it have the food
        // Greedent joins the team, level equal to 2 below highest party member (shiny locked)
        const level = getHighestLevelPlayerPokemon(false, true).level - 2;
        const greedent = new EnemyPokemon(
          speciesDataRegistry.getSpecies(SpeciesId.GREEDENT),
          level,
          TrainerSlot.NONE,
          false,
          true,
        );
        greedent.moveset = [
          new PokemonMove(MoveId.THRASH),
          new PokemonMove(MoveId.BODY_PRESS),
          new PokemonMove(MoveId.STUFF_CHEEKS),
          new PokemonMove(MoveId.SLACK_OFF),
        ];
        greedent.passive = true;

        await transitionMysteryEncounterIntroVisuals(true, true, 500);
        await catchPokemon(greedent, null, PokeballType.POKEBALL, false);
        leaveEncounterWithoutBattle(true);
      })
      .build(),
  )
  .build();

/**
 * The most berries of `berryMod`'s type the Greedent can hold (local fork).
 * The Greedent is an enemy, so it keeps the base caps even in Endless; a berry asked without a holder reports
 * exactly that base cap.
 */
function getBossBerryCap(berryMod: PokemonHeldItemModifier): number {
  return berryMod.getMaxHeldItemCount();
}

/**
 * Draws `count` of a Pokemon's stolen berries at random without replacement (local fork).
 * Like the base game, every mode except Endless reshuffles the remaining berries before each draw, so its RNG use is
 * unchanged. Endless allows 99 berries per type, which makes that quadratic, so it shuffles once and takes from the
 * end: the same uniform draw.
 * @param berryTypes - One entry per stolen berry; emptied of the drawn berries
 * @param count - How many berries to draw
 * @returns How many of each type were drawn, in the order each type was first drawn
 */
function drawReturnedBerries(berryTypes: BerryType[], count: number): Map<BerryType, number> {
  const reshuffleEachDraw = !globalScene.gameMode.isEndless;
  if (!reshuffleEachDraw) {
    Phaser.Math.RND.shuffle(berryTypes);
  }

  const drawn = new Map<BerryType, number>();
  for (let i = 0; i < count && berryTypes.length > 0; i++) {
    if (reshuffleEachDraw) {
      // Shuffle remaining berry types and pop
      Phaser.Math.RND.shuffle(berryTypes);
    }
    const randBerryType = berryTypes.pop()!;
    drawn.set(randBerryType, (drawn.get(randBerryType) ?? 0) + 1);
  }
  return drawn;
}

/**
 * Gives the drawn berries back to `pokemon`, one stack per type instead of one berry at a time (local fork).
 * As before, berries past what the Pokemon can still hold are lost. The caller updates the modifiers once afterwards.
 */
function returnBerriesToPokemon(pokemon: PlayerPokemon, berries: Map<BerryType, number>): void {
  berries.forEach((count, berryType) => {
    const berryModType = generateModifierType(modifierTypes.BERRY, [berryType]) as BerryModifierType;
    const berryMod = berryModType.newModifier(pokemon) as BerryModifier;
    const existing = globalScene.findModifier(
      m => m instanceof BerryModifier && m.pokemonId === pokemon.id && m.matchType(berryMod),
    ) as BerryModifier | undefined;
    berryMod.stackCount = Math.min(count, existing ? existing.getCountUnderMax() : berryMod.getMaxStackCount());
    if (berryMod.stackCount > 0) {
      globalScene.addModifier(berryMod, true, false, false, true);
    }
  });
}

function doGreedentSpriteSteal() {
  const shakeDelay = 50;
  const slideDelay = 500;

  const greedentSprites = globalScene.currentBattle.mysteryEncounter!.introVisuals?.getSpriteAtIndex(1);

  audioManager.playSound("battle_anims/Follow Me");
  globalScene.tweens.chain({
    targets: greedentSprites,
    tweens: [
      {
        // Slide Greedent diagonally
        duration: slideDelay,
        ease: "Cubic.easeOut",
        y: "+=75",
        x: "-=65",
        scale: 1.1,
      },
      {
        // Shake
        duration: shakeDelay,
        ease: "Cubic.easeOut",
        yoyo: true,
        x: (randInt(2) > 0 ? "-=" : "+=") + 5,
        y: (randInt(2) > 0 ? "-=" : "+=") + 5,
      },
      {
        // Shake
        duration: shakeDelay,
        ease: "Cubic.easeOut",
        yoyo: true,
        x: (randInt(2) > 0 ? "-=" : "+=") + 5,
        y: (randInt(2) > 0 ? "-=" : "+=") + 5,
      },
      {
        // Shake
        duration: shakeDelay,
        ease: "Cubic.easeOut",
        yoyo: true,
        x: (randInt(2) > 0 ? "-=" : "+=") + 5,
        y: (randInt(2) > 0 ? "-=" : "+=") + 5,
      },
      {
        // Shake
        duration: shakeDelay,
        ease: "Cubic.easeOut",
        yoyo: true,
        x: (randInt(2) > 0 ? "-=" : "+=") + 5,
        y: (randInt(2) > 0 ? "-=" : "+=") + 5,
      },
      {
        // Shake
        duration: shakeDelay,
        ease: "Cubic.easeOut",
        yoyo: true,
        x: (randInt(2) > 0 ? "-=" : "+=") + 5,
        y: (randInt(2) > 0 ? "-=" : "+=") + 5,
      },
      {
        // Shake
        duration: shakeDelay,
        ease: "Cubic.easeOut",
        yoyo: true,
        x: (randInt(2) > 0 ? "-=" : "+=") + 5,
        y: (randInt(2) > 0 ? "-=" : "+=") + 5,
      },
      {
        // Slide Greedent diagonally
        duration: slideDelay,
        ease: "Cubic.easeOut",
        y: "-=75",
        x: "+=65",
        scale: 1,
      },
      {
        // Bounce at the end
        duration: 300,
        ease: "Cubic.easeOut",
        yoyo: true,
        y: "-=20",
        loop: 1,
      },
    ],
  });
}

function doGreedentEatBerries() {
  const greedentSprites = globalScene.currentBattle.mysteryEncounter!.introVisuals?.getSpriteAtIndex(1);
  let index = 1;
  globalScene.tweens.add({
    targets: greedentSprites,
    duration: 150,
    ease: "Cubic.easeOut",
    yoyo: true,
    y: "-=8",
    loop: 5,
    onStart: () => {
      audioManager.playSound("battle_anims/PRSFX- Bug Bite");
    },
    onLoop: () => {
      if (index % 2 === 0) {
        audioManager.playSound("battle_anims/PRSFX- Bug Bite");
      }
      index++;
    },
  });
}

/**
 * @param isEat Default false. Will "create" pile when false, and remove pile when true.
 */
function doBerrySpritePile(isEat = false) {
  const berryAddDelay = 150;
  let animationOrder = [
    "starf",
    "sitrus",
    "lansat",
    "salac",
    "apicot",
    "enigma",
    "liechi",
    "ganlon",
    "lum",
    "petaya",
    "leppa",
  ];
  if (isEat) {
    animationOrder = animationOrder.reverse();
  }
  const encounter = globalScene.currentBattle.mysteryEncounter!;
  animationOrder.forEach((berry, i) => {
    const introVisualsIndex = encounter.spriteConfigs.findIndex(config => config.spriteKey?.includes(berry));
    let sprite: Phaser.GameObjects.Sprite;
    let tintSprite: Phaser.GameObjects.Sprite;
    const sprites = encounter.introVisuals?.getSpriteAtIndex(introVisualsIndex);
    if (sprites) {
      sprite = sprites[0];
      tintSprite = sprites[1];
    }
    globalScene.time.delayedCall(berryAddDelay * i + 400, () => {
      if (sprite) {
        sprite.setVisible(!isEat);
      }
      if (tintSprite) {
        tintSprite.setVisible(!isEat);
      }

      // Animate Petaya berry falling off the pile
      if (berry === "petaya" && sprite && tintSprite && !isEat) {
        globalScene.time.delayedCall(200, () => {
          doBerryBounce([sprite, tintSprite], 30, 500);
        });
      }
    });
  });
}

function doBerryBounce(berrySprites: Phaser.GameObjects.Sprite[], yd: number, baseBounceDuration: number) {
  let bouncePower = 1;
  let bounceYOffset = yd;

  const doBounce = () => {
    globalScene.tweens.add({
      targets: berrySprites,
      y: "+=" + bounceYOffset,
      x: { value: "+=" + bouncePower * bouncePower * 10, ease: "Linear" },
      duration: bouncePower * baseBounceDuration,
      ease: "Cubic.easeIn",
      onComplete: () => {
        bouncePower = bouncePower > 0.01 ? bouncePower * 0.5 : 0;

        if (bouncePower) {
          bounceYOffset *= bouncePower;

          globalScene.tweens.add({
            targets: berrySprites,
            y: "-=" + bounceYOffset,
            x: { value: "+=" + bouncePower * bouncePower * 10, ease: "Linear" },
            duration: bouncePower * baseBounceDuration,
            ease: "Cubic.easeOut",
            onComplete: () => doBounce(),
          });
        }
      },
    });
  };

  doBounce();
}
