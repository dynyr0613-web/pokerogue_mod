/**
 * Endless-only balance knobs of the local fork (the user's "엔드리스 제한 해제", 2026-11-02).
 *
 * Classic, Challenge and Daily keep the base game's values: every function here returns the base
 * value unless the current game mode is Endless or Spliced Endless, and the held-item caps only
 * apply to the player's Pokémon (enemies already scale through their tokens).
 */
import { globalScene } from "#app/global-scene";
import { ModifierTier } from "#enums/modifier-tier";
import type { Pokemon } from "#field/pokemon";

/** Held-item stack caps for the player's Pokémon in Endless; the base caps are in the comments. */
export const ENDLESS_HELD_ITEM_CAPS = {
  /** Every berry type (base 2 for Lum, Leppa, Sitrus and Enigma, 3 for the rest) */
  BERRY: 99,
  /** 먹다남은음식, TurnHealModifier (base 4) */
  LEFTOVERS: 6,
  /** 조개껍질방울, HitHealModifier (base 4) */
  SHELL_BELL: 8,
  /** 끈기갈고리손톱, ContactHeldItemTransferChanceModifier (base 5) */
  GRIP_CLAW: 7,
  /** 선제공격손톱, BypassSpeedChanceModifier (base 3) */
  QUICK_CLAW: 5,
} as const;

export type EndlessCappedItem = keyof typeof ENDLESS_HELD_ITEM_CAPS;

/**
 * Held-item stack caps for the player's Pokémon in every mode (the user's request, 2026-11-05). Enemies keep
 * the base cap, so trainers can't stack Scope Lenses into guaranteed crits. Known and accepted, like the Endless
 * caps: encounters that copy the player's team onto enemies (Weird Dream, Training Session, Dark Deal) copy the
 * player's stacks too.
 */
export const PLAYER_HELD_ITEM_CAPS = {
  /** 초점렌즈, CritBoosterModifier (base 1); +1 crit stage per lens, so 3 always crit */
  SCOPE_LENS: 3,
  /** 멀티렌즈, PokemonMultiHitModifier (base 2); the first hit stays at 75%, each lens adds a 25% hit */
  MULTI_LENS: 4,
  /** 돌격조끼 (fork item, base 1); +50% Sp. Def per vest, added up */
  ASSAULT_VEST: 3,
  /** 방탄조끼 (fork item, base 1); +50% Defense per vest, added up */
  BULLETPROOF_VEST: 3,
  /** 프리즘 (fork item, base 1); the partner takes 50/75/100% of each hit with 1/2/3 Prisms */
  PRISM: 3,
} as const;

export type PlayerCappedItem = keyof typeof PLAYER_HELD_ITEM_CAPS;

/**
 * The stack cap of a held item for `pokemon`: {@linkcode PLAYER_HELD_ITEM_CAPS} for the player's Pokémon in
 * every mode, otherwise `baseCap`.
 */
export function playerHeldItemCap(pokemon: Pokemon | undefined, baseCap: number, item: PlayerCappedItem): number {
  return pokemon?.isPlayer() ? Math.max(baseCap, PLAYER_HELD_ITEM_CAPS[item]) : baseCap;
}

/** Set by {@linkcode withEndlessCapMode} while a past run is shown (Run History) */
let capModeOverride: boolean | undefined;

/**
 * Evaluates `fn` with the held-item caps of the given mode instead of the current game mode, e.g. to
 * show a past Endless run's item counts from the title screen.
 */
export function withEndlessCapMode<T>(isEndless: boolean, fn: () => T): T {
  const previous = capModeOverride;
  capModeOverride = isEndless;
  try {
    return fn();
  } finally {
    capModeOverride = previous;
  }
}

function isEndlessPlayer(pokemon?: Pokemon): boolean {
  return !!pokemon?.isPlayer() && (capModeOverride ?? !!globalScene?.gameMode?.isEndless);
}

/**
 * The stack cap of a held item for `pokemon`: the Endless cap for the player's Pokémon in Endless,
 * otherwise `baseCap` (never lower than the base cap).
 */
export function endlessHeldItemCap(pokemon: Pokemon | undefined, baseCap: number, item: EndlessCappedItem): number {
  if (!isEndlessPlayer(pokemon)) {
    return baseCap;
  }
  return Math.max(baseCap, ENDLESS_HELD_ITEM_CAPS[item]);
}

/** Counts out of 1024 in the order COMMON, GREAT, ULTRA, ROGUE, MASTER */
export type TierCounts = readonly [number, number, number, number, number];

/** The base game's tier odds: 75.0% / 19.0% / 4.7% / 1.2% / 0.1% */
export const BASE_TIER_COUNTS: TierCounts = [768, 195, 48, 12, 1];

/**
 * Reward tier odds per wave band for the player's reward pool in Endless. The first band equals the
 * base game; later bands move weight from COMMON to the rarer tiers. MASTER grows slowly on purpose:
 * the Endless MASTER pool is small (Shiny Charm, Healing Charm, Multi Lens, DNA Splicers, Mini Black
 * Hole, the vests and Prism), so 2.3% per slot would saturate it within a few hundred waves.
 *
 * 2026-11-06 (the user): COMMON at luck 0 is about 55% of all rewards from wave 500 and about 40% from
 * wave 1000 (COMMON count = target × 1024 / (1 - 4/128), since luck 0 still upgrades 1 roll in 32). The
 * freed weight went to GREAT, ULTRA and ROGUE in their old ratio; MASTER stays at 6 and 12.
 */
export const ENDLESS_TIER_BANDS: readonly { minWave: number; counts: TierCounts }[] = [
  { minWave: 0, counts: BASE_TIER_COUNTS },
  { minWave: 200, counts: [704, 224, 72, 22, 2] },
  { minWave: 500, counts: [581, 277, 111, 49, 6] },
  { minWave: 1000, counts: [423, 346, 151, 92, 12] },
];

export function getEndlessTierCounts(wave: number): TierCounts {
  let counts = BASE_TIER_COUNTS;
  for (const band of ENDLESS_TIER_BANDS) {
    if (wave >= band.minWave) {
      counts = band.counts;
    }
  }
  return counts;
}

/**
 * Maps a roll in `[0, 1024)` to a tier with the given counts. Like the base game, the low rolls are
 * the rare tiers: roll 0 is MASTER with the base counts.
 */
export function tierFromRoll(tierValue: number, counts: TierCounts): ModifierTier {
  const [, great, ultra, rogue, master] = counts;
  if (tierValue < master) {
    return ModifierTier.MASTER;
  }
  if (tierValue < master + rogue) {
    return ModifierTier.ROGUE;
  }
  if (tierValue < master + rogue + ultra) {
    return ModifierTier.ULTRA;
  }
  if (tierValue < master + rogue + ultra + great) {
    return ModifierTier.GREAT;
  }
  return ModifierTier.COMMON;
}

/** `true` when the player's reward tier roll should use the Endless band table */
export function usesEndlessTierBands(): boolean {
  return !!globalScene?.gameMode?.isEndless;
}

/** The current wave, or 0 before the first battle exists (e.g. while starting a run) */
export function currentWave(): number {
  return globalScene?.currentBattle?.waveIndex ?? 0;
}
