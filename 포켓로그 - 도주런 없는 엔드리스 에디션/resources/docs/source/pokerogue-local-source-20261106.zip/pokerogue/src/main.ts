import "#app/polyfills"; // All polyfills MUST be loaded first for side effects
import "#init/init-manifest"; // initializes the manifest, must be done *before* i18n is initialized due to being used for caching
import "#app/i18n"; // Initializes i18n on import

import { isMobile, preventDoubleTapZoom } from "#app/touch-controls";
import { isBeta, isDev } from "#constants/app-constants";
import { version } from "#package.json";
import Phaser from "phaser";
import BBCodeTextPlugin from "phaser4-rex-plugins/plugins/bbcodetext-plugin";
import InputTextPlugin from "phaser4-rex-plugins/plugins/inputtext-plugin";
import TransitionImagePackPlugin from "phaser4-rex-plugins/templates/transitionimagepack/transitionimagepack-plugin";
import UIPlugin from "phaser4-rex-plugins/templates/ui/ui-plugin";

if (isBeta || isDev) {
  document.title += " (Beta)";
}

preventDoubleTapZoom();

async function startGame(): Promise<void> {
  const { initSettingsManager } = await import("#app/global-settings-manager");
  const { initGlobalAudioManager } = await import("#app/global-audio-manager");

  await initSettingsManager();
  const audioManager = await initGlobalAudioManager();

  const LoadingScene = (await import("./loading-scene")).LoadingScene;
  const BattleScene = (await import("./battle-scene")).BattleScene;
  const game = new Phaser.Game({
    type: Phaser.WEBGL,
    parent: "app",
    audio: {
      noAudio: !audioManager.isAudioEnabled,
    },
    scale: {
      width: 1920,
      height: 1080,
      mode: Phaser.Scale.FIT,
    },
    plugins: {
      global: [
        {
          key: "rexInputTextPlugin",
          plugin: InputTextPlugin,
          start: true,
        },
        {
          key: "rexBBCodeTextPlugin",
          plugin: BBCodeTextPlugin,
          start: true,
        },
        {
          key: "rexTransitionImagePackPlugin",
          plugin: TransitionImagePackPlugin,
          start: true,
        },
      ],
      scene: [
        {
          key: "rexUI",
          plugin: UIPlugin,
          mapping: "rexUI",
        },
      ],
    },
    input: {
      mouse: {
        target: "app",
      },
      touch: {
        target: "app",
      },
      gamepad: true,
    },
    dom: {
      createContainer: true,
    },
    antialias: false,
    scene: [LoadingScene, BattleScene],
    version,
  });
  game.sound.pauseOnBlur = isMobile();

  // Local only: the Dev Bridge lets Bridge/bridge.sh drive the game while the dev server runs
  if (import.meta.env.DEV && import.meta.env.VITE_DEV_BRIDGE === "1") {
    const { startDevBridge } = await import("./dev-bridge/dev-bridge");
    startDevBridge(game);
  }
}

try {
  await Promise.all([document.fonts.load("16px emerald"), document.fonts.load("10px pkmnems")]);
} catch (err) {
  console.error("Error loading fonts:", err);
} finally {
  await startGame();
}
