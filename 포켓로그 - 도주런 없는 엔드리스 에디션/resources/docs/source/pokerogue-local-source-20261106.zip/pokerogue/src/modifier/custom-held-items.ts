/**
 * Held items added by this local fork (2026-11-02).
 *
 * They live outside `modifier.ts` so that file stays close to upstream. Session saves look modifier
 * classes up by name in the `modifier.ts` module namespace, so `ModifierData.toModifier` falls back to
 * {@linkcode getCustomModifierClass} for the classes defined here.
 */

import { applyAbAttrs } from "#abilities/apply-ab-attrs";
import { globalScene } from "#app/global-scene";
import { getPokemonNameWithAffix } from "#app/messages";
import { playerHeldItemCap } from "#balance/endless-balance";
import { HitResult } from "#enums/hit-result";
import { Stat } from "#enums/stat";
import type { Pokemon } from "#field/pokemon";
import type { Modifier, PersistentModifier } from "#modifiers/modifier";
import { PokemonHeldItemModifier, StatBoosterModifier } from "#modifiers/modifier";
import type { ModifierType } from "#modifiers/modifier-type";
import { BooleanHolder, type NumberHolder, toDmgValue } from "#utils/common";
import i18next from "i18next";

/** Vests: stat added per vest, added up (1 = x1.5, 2 = x2, 3 = x2.5); the user's request, 2026-11-05 */
export const VEST_BOOST_PER_STACK = 0.5;

/**
 * Assault Vest (돌격조끼): the holder's Sp. Def gets +50% per vest, added up (x1.5 / x2 / x2.5). Unlike the
 * main-series item it does not restrict the holder's moves. Up to 3 on the player's Pokémon, transferable.
 * Other stat items (Eviolite...) still multiply with it.
 */
export class AssaultVestModifier extends StatBoosterModifier {
  constructor(type: ModifierType, pokemonId: number, stackCount?: number) {
    super(type, pokemonId, [Stat.SPDEF], 1 + VEST_BOOST_PER_STACK, stackCount);
  }

  override apply(_pokemon: Pokemon, _stat: Stat, statValue: NumberHolder): boolean {
    statValue.value *= 1 + VEST_BOOST_PER_STACK * this.getStackCount();
    return true;
  }

  override matchType(modifier: Modifier): boolean {
    return modifier instanceof AssaultVestModifier;
  }

  override clone(): AssaultVestModifier {
    return new AssaultVestModifier(this.type, this.pokemonId, this.stackCount);
  }

  /** Only the holder's id is saved; the stat and multiplier are fixed by the class (see the constructor). */
  override getArgs(): any[] {
    return [this.pokemonId];
  }

  override getMaxHeldItemCount(pokemon?: Pokemon): number {
    return playerHeldItemCap(pokemon, 1, "ASSAULT_VEST");
  }
}

/**
 * Bulletproof Vest (방탄조끼): the holder's Defense gets +50% per vest, added up (x1.5 / x2 / x2.5).
 * Up to 3 on the player's Pokémon, transferable.
 */
export class BulletproofVestModifier extends StatBoosterModifier {
  constructor(type: ModifierType, pokemonId: number, stackCount?: number) {
    super(type, pokemonId, [Stat.DEF], 1 + VEST_BOOST_PER_STACK, stackCount);
  }

  override apply(_pokemon: Pokemon, _stat: Stat, statValue: NumberHolder): boolean {
    statValue.value *= 1 + VEST_BOOST_PER_STACK * this.getStackCount();
    return true;
  }

  override matchType(modifier: Modifier): boolean {
    return modifier instanceof BulletproofVestModifier;
  }

  override clone(): BulletproofVestModifier {
    return new BulletproofVestModifier(this.type, this.pokemonId, this.stackCount);
  }

  /** Only the holder's id is saved; the stat and multiplier are fixed by the class (see the constructor). */
  override getArgs(): any[] {
    return [this.pokemonId];
  }

  override getMaxHeldItemCount(pokemon?: Pokemon): number {
    return playerHeldItemCap(pokemon, 1, "BULLETPROOF_VEST");
  }
}

/** Life Orb: damage added per orb (1 = x1.3, 2 = x1.6, 3 = x1.9) */
export const LIFE_ORB_DAMAGE_PER_STACK = 0.3;
/** Life Orb: share of max HP lost at the end of an attacking turn, for 1, 2 and 3 orbs */
export const LIFE_ORB_HP_LOSS: readonly number[] = [0.1, 0.15, 0.2];

/**
 * Life Orb (생명의구슬), the user's version (2026-11-05):
 * - the holder's attacks deal 30% more damage per orb, added up rather than multiplied
 *   (1 = x1.3, 2 = x1.6, 3 = x1.9), see {@linkcode applyLifeOrbDamage};
 * - at the end of a turn in which it used an attacking move (`PokemonTurnData.usedAttackMove`, set when the
 *   move is executed, hit or miss), it loses 10/15/20% of its max HP for 1/2/3 orbs. Turns without an
 *   attacking move cost nothing. Magic Guard blocks the loss like other indirect damage.
 * Up to 3 per Pokémon, transferable.
 */
export class LifeOrbModifier extends PokemonHeldItemModifier {
  override matchType(modifier: Modifier): boolean {
    return modifier instanceof LifeOrbModifier;
  }

  override clone(): LifeOrbModifier {
    return new LifeOrbModifier(this.type, this.pokemonId, this.stackCount);
  }

  /** The multiplier for the holder's attack damage */
  getDamageMultiplier(): number {
    return 1 + LIFE_ORB_DAMAGE_PER_STACK * this.getStackCount();
  }

  /** The share of max HP lost at the end of a turn in which the holder attacked */
  getHpLossRatio(): number {
    const stacks = Math.min(Math.max(this.getStackCount(), 1), LIFE_ORB_HP_LOSS.length);
    return LIFE_ORB_HP_LOSS[stacks - 1];
  }

  /**
   * Turn end (`TurnEndPhase`): the holder loses HP if it used an attacking move this turn.
   * @param pokemon - The holder
   * @returns Whether HP was lost
   */
  override apply(pokemon: Pokemon): boolean {
    if (!pokemon.turnData.usedAttackMove || pokemon.isFainted()) {
      return false;
    }
    const cancelled = new BooleanHolder(false);
    applyAbAttrs("BlockNonDirectDamageAbAttr", { pokemon, cancelled });
    if (cancelled.value) {
      return false;
    }
    pokemon.damageAndUpdate(toDmgValue(pokemon.getMaxHp() * this.getHpLossRatio()), { result: HitResult.INDIRECT });
    globalScene.phaseManager.queueMessage(
      i18next.t("modifier:lifeOrbApply", {
        pokemonNameWithAffix: getPokemonNameWithAffix(pokemon),
        typeName: this.type.name,
      }),
    );
    return true;
  }

  override getMaxHeldItemCount(_pokemon?: Pokemon): number {
    return LIFE_ORB_HP_LOSS.length;
  }
}

/**
 * Multiply an attack's damage by the attacker's Life Orbs (called from `Pokemon.getAttackDamage`).
 * @param source - The attacker
 * @param damage - The damage so far, changed in place
 */
export function applyLifeOrbDamage(source: Pokemon, damage: NumberHolder): void {
  const orb = source.getHeldItems().find(m => m instanceof LifeOrbModifier);
  if (orb) {
    damage.value = toDmgValue(damage.value * orb.getDamageMultiplier());
  }
}

/**
 * Prism: share of a single-target hit's damage that also lands on the target's partner, by the number of Prisms
 * held: 50/75/100% for 1/2/3 (the user, 2026-11-05 night; one Prism used to be the limit)
 */
export const PRISM_SPLASH_RATIOS = [0.5, 0.75, 1] as const;
/** One Prism's share */
export const PRISM_SPLASH_RATIO = PRISM_SPLASH_RATIOS[0];

/**
 * Prism (프리즘), MASTER tier (the user's design, 2026-11-05): every hit of the holder's single-target attacks
 * also deals a share of its damage to the target's partner on the field, so it only matters in double battles:
 * 50/75/100% with 1/2/3 Prisms ({@linkcode PRISM_SPLASH_RATIOS}). Spread moves are not affected. With one Prism
 * and 4 Multi Lenses the target takes 75/25/25/25/25% and the partner 37.5/12.5/12.5/12.5/12.5%. The splash is a
 * flat share of the hit (no type matchup); Protect, semi-invulnerability (Fly, Dig...) and a Substitute keep the
 * partner out of it. Applied by `MoveEffectPhase.applyPrismSplash`. Up to 3 on the player's Pokémon (1 on an
 * enemy's, like the vests), transferable.
 */
export class PrismModifier extends PokemonHeldItemModifier {
  override matchType(modifier: Modifier): boolean {
    return modifier instanceof PrismModifier;
  }

  override clone(): PrismModifier {
    return new PrismModifier(this.type, this.pokemonId, this.stackCount);
  }

  /** The share of each hit's damage that the target's partner takes: 50/75/100% for 1/2/3 Prisms */
  getSplashRatio(): number {
    return PRISM_SPLASH_RATIOS[Math.min(this.getStackCount(), PRISM_SPLASH_RATIOS.length) - 1];
  }

  /** Not used through `applyModifiers`; see `MoveEffectPhase.applyPrismSplash` */
  override apply(_pokemon: Pokemon): boolean {
    return false;
  }

  override getMaxHeldItemCount(pokemon?: Pokemon): number {
    return playerHeldItemCap(pokemon, 1, "PRISM");
  }
}

const customModifierClasses: Readonly<Record<string, new (...args: any[]) => PersistentModifier>> = Object.freeze({
  AssaultVestModifier,
  BulletproofVestModifier,
  LifeOrbModifier,
  PrismModifier,
});

/**
 * Look up one of this file's modifier classes by its class name, the way save data refers to it
 * (`ModifierData.className`).
 * @param className - The constructor name stored in the session save
 * @returns The class, or `undefined` when the name is not one of ours
 */
export function getCustomModifierClass(className: string): (new (...args: any[]) => PersistentModifier) | undefined {
  return customModifierClasses[className];
}
