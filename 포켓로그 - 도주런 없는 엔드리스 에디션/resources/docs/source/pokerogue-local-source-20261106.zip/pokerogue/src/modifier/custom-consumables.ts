/**
 * Consumable items added by this local fork (2026-11-05).
 *
 * Kept outside `modifier.ts` like `custom-held-items.ts`. Consumables are used the moment they are picked and
 * never saved, so they need no entry in `customModifierClasses`.
 */

import { globalScene } from "#app/global-scene";
import { FRIENDSHIP_GAIN_FROM_RARE_CANDY } from "#balance/starters";
import { getLevelTotalExp } from "#data/exp";
import type { PlayerPokemon } from "#field/pokemon";
import { ConsumablePokemonModifier, LevelIncrementBoosterModifier } from "#modifiers/modifier";
import { NumberHolder } from "#utils/common";

/** Candy Pile (사탕더미) = this many Rare Candies on the chosen Pokémon... (the user, 2026-11-05) */
export const CANDY_PILE_RARE_CANDIES = 5;
/** ...then this many Rarer Candies, which reach every party member (the chosen one too) */
export const CANDY_PILE_RARER_CANDIES = 2;

/** Levels a single Rare Candy gives right now: 1, plus 1 per Candy Jar. */
export function levelsPerCandy(): number {
  const levels = new NumberHolder(1);
  globalScene.applyModifiers(LevelIncrementBoosterModifier, true, levels);
  return levels.value;
}

/**
 * What one Rare Candy does to the Pokémon itself (see `PokemonLevelIncrementModifier.apply`): `perCandy` levels,
 * exp set to the new level's total while under the exp level cap, and Rare Candy friendship. The caller queues
 * the level-up phase.
 */
export function feedCandy(pokemon: PlayerPokemon, perCandy: number): void {
  pokemon.level += perCandy;
  if (pokemon.level <= globalScene.getMaxExpLevel(true)) {
    pokemon.exp = getLevelTotalExp(pokemon.level, pokemon.species.growthRate);
  }
  pokemon.addFriendship(FRIENDSHIP_GAIN_FROM_RARE_CANDY, true);
}

/**
 * Candy Pile (사탕더미), ROGUE tier: 5 Rare Candies on the chosen Pokémon, then 2 Rarer Candies on the whole party
 * (fainted members too), in one pick. Candy Jars add to every candy. The candies are fed one by one by
 * `CandyPilePhase`, so evolutions and level-up moves happen exactly as with the separate items.
 */
export class CandyPileModifier extends ConsumablePokemonModifier {
  override apply(target: PlayerPokemon): boolean {
    globalScene.phaseManager.unshiftNew(
      "CandyPilePhase",
      target.id,
      CANDY_PILE_RARE_CANDIES,
      CANDY_PILE_RARER_CANDIES,
      levelsPerCandy(),
    );
    return true;
  }
}
