import { globalScene } from "#app/global-scene";
import { Phase } from "#app/phase";
import type { PlayerPokemon } from "#field/pokemon";
import { feedCandy } from "#modifiers/custom-consumables";

/**
 * Local fork (2026-11-05): feeds a Candy Pile (사탕더미) candy by candy, so it ends exactly where 5 Rare Candies on
 * the chosen Pokémon and then 2 Rarer Candies would: every evolution on the way happens (Caterpie -> Metapod ->
 * Butterfree), moves are offered from the learnset of the species at that point, evolutions that need a move or
 * friendship see what they would see, and a Shedinja that appears partway gets the Rarer Candies still to come.
 *
 * Each step queues its level-up phase(s) and then the next step. The level-up phase's own learn-move and evolution
 * phases run before that next step (they sit one level higher in the phase tree).
 *
 * The chosen Pokémon's Rare Candies are grouped into one level-up while nothing can happen in between: a group ends
 * with the candy whose own level-up would offer a level-up move or start an evolution. Each Rarer Candy round is
 * one level-up per party member, like the real item.
 */
export class CandyPilePhase extends Phase {
  public readonly phaseName = "CandyPilePhase";
  private readonly targetId: number;
  private readonly rareLeft: number;
  private readonly rarerLeft: number;
  private readonly perCandy: number;

  constructor(targetId: number, rareLeft: number, rarerLeft: number, perCandy: number) {
    super();
    this.targetId = targetId;
    this.rareLeft = rareLeft;
    this.rarerLeft = rarerLeft;
    this.perCandy = perCandy;
  }

  public override start(): void {
    super.start();

    const { phaseManager } = globalScene;
    const party = globalScene.getPlayerParty();
    const target = party.find(p => p.id === this.targetId);

    if (this.rareLeft > 0 && target) {
      const lastLevel = target.level;
      let used = 0;
      while (used < this.rareLeft) {
        const before = target.level;
        feedCandy(target, this.perCandy);
        used++;
        if (CandyPilePhase.levelUpDoesSomething(target, before)) {
          break;
        }
      }
      phaseManager.unshiftNew("LevelUpPhase", party.indexOf(target), lastLevel, target.level);
      phaseManager.unshiftNew("CandyPilePhase", this.targetId, this.rareLeft - used, this.rarerLeft, this.perCandy);
    } else if (this.rarerLeft > 0) {
      for (const pokemon of party) {
        const lastLevel = pokemon.level;
        feedCandy(pokemon, this.perCandy);
        phaseManager.unshiftNew("LevelUpPhase", party.indexOf(pokemon), lastLevel, pokemon.level);
      }
      phaseManager.unshiftNew("CandyPilePhase", this.targetId, 0, this.rarerLeft - 1, this.perCandy);
    }

    this.end();
  }

  /**
   * Whether a level-up from `before` to the Pokémon's current level would offer a move or start an evolution,
   * checked the way `LevelUpPhase.end` does.
   */
  static levelUpDoesSomething(pokemon: PlayerPokemon, before: number): boolean {
    if (
      before < 100
      && pokemon.getLevelMoves({ startingLevel: before + 1, includePrevolutionMoves: true }).length > 0
    ) {
      return true;
    }
    return !pokemon.pauseEvolutions && pokemon.getEvolution() != null;
  }
}
