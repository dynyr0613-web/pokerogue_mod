import { EVOLVE_MOVE, RELEARN_MOVE } from "#app/constants";
import { speciesDataRegistry } from "#app/global-species-data-registry";
import { LearnMoveSituation } from "#enums/learn-move-situation";
import { LearnableMoveSource } from "#enums/learnable-move-source";
import type { MoveId } from "#enums/move-id";
import type { LevelMoveContext, LevelMovesWithSource } from "#types/level-moves";

/**
 * Helper method for {@linkcode getLevelMoves}
 *
 * Get all level moves the species form can learn on its own.
 * @param context - Basic information about the Pokemon to get the level moves for
 * @param includeEvolutionMoves - Whether to include evolution moves
 * @param includeRelearnerMoves - Whether to include moves that would require a relearner. Note the move relearner inherently allows evolution moves
 * @param fromFusion - (Default `false`) Whether to get the moves from the fusion species
 * @remarks
 * `fromFusion` should only be used if a fusion species is being provided.
 * @returns A list of moves and the levels they can be learned at, along with the source of the move.
 * Excludes moves from prevolutions, but includes evolution moves and relearner moves.
 */
function getRegularLevelMoves(
  context: LevelMoveContext,
  includeEvolutionMoves: boolean,
  includeRelearnerMoves: boolean,
  fromFusion = false,
): LevelMovesWithSource {
  const ret: LevelMovesWithSource = [];
  const moves = fromFusion
    ? context.fusionSpeciesForm!.getLevelMoves(context.fusionFormKey!)
    : context.pokemonSpeciesForm.getLevelMoves(context.pokemonFormKey);
  for (const [level, move] of moves) {
    if (
      (includeEvolutionMoves && level === EVOLVE_MOVE)
      || (includeRelearnerMoves && level === RELEARN_MOVE)
      || level > 0
    ) {
      let moveSource: LearnableMoveSource;
      switch (level) {
        case RELEARN_MOVE:
          moveSource = LearnableMoveSource.RELEARN;
          break;
        case EVOLVE_MOVE:
          moveSource = LearnableMoveSource.EVOLUTION;
          break;
        default:
          moveSource = LearnableMoveSource.LEVEL;
          break;
      }
      ret.push([level, move, (moveSource + +fromFusion) as LearnableMoveSource]);
    }
  }
  return ret;
}

/**
 * Helper method for {@linkcode getLevelMoves}
 *
 * Get all level moves the species form and its prevolutions can learn.
 * @param context - Basic information about the Pokemon to get the level moves for
 * @param includeEvolutionMoves - Whether to include evolution moves
 * @param includeRelearnerMoves - Whether to include moves that would require a relearner. Note the move relearner inherently allows evolution moves
 * @param fromFusion - (Default `false`) Whether to get the prevolution moves from the fusion species
 * @remarks
 * `fromFusion` should only be used if a fusion species is being provided.
 * @returns A list of moves and the levels they can be learned at, along with the source of the move
 */
function getPrevolutionMoves(
  context: LevelMoveContext,
  includeEvolutionMoves: boolean,
  includeRelearnerMoves: boolean,
  fromFusion = false,
): LevelMovesWithSource {
  const ret: LevelMovesWithSource = [];
  const speciesBase = fromFusion ? context.fusionSpeciesForm! : context.pokemonSpeciesForm;

  if (!speciesBase && fromFusion) {
    // TODO: Find a better way to handle `fromFusion=true` without being a fusion
    console.warn("`getPrevolutionMoves` was called with `fromFusion=true` but the pokemon is not a fusion!");
    return ret;
  }

  const evolutionLine = [...speciesDataRegistry.getPrevolutionChain(speciesBase.speciesId), speciesBase.speciesId];
  for (let index = 0; index < evolutionLine.length; index++) {
    const isPrevo = index < evolutionLine.length - 1;
    const speciesLevelMoves = speciesDataRegistry
      .getPokemonSpeciesForm(evolutionLine[index], context.pokemonFormKey)
      .getLevelMoves();

    for (const [level, move] of speciesLevelMoves) {
      const includeLevelOne = !index || level > 1 || includeRelearnerMoves;

      if (includeRelearnerMoves && level === RELEARN_MOVE) {
        const source = isPrevo ? LearnableMoveSource.PREVO : LearnableMoveSource.RELEARN;
        ret.push([level, move, (source + +fromFusion) as LearnableMoveSource]);
      } else if (includeEvolutionMoves && level === EVOLVE_MOVE) {
        const source = isPrevo ? LearnableMoveSource.PREVO : LearnableMoveSource.EVOLUTION;
        ret.push([level, move, (source + +fromFusion) as LearnableMoveSource]);
      } else if (includeLevelOne && (!isPrevo || level <= context.level)) {
        const source = isPrevo ? LearnableMoveSource.PREVO : LearnableMoveSource.LEVEL;
        ret.push([level, move, (source + +fromFusion) as LearnableMoveSource]);
      }
    }
  }
  return ret;
}

/**
 * Helper function for {@linkcode filterAndSortLevelMoves}
 *
 * @remarks
 * Finds all non-duplicate items from the input, and pushes them into the output.
 * Two items count as duplicate if they have the same Move, regardless of level.
 *
 * @param levelMoves - The input array to search for non-duplicates from
 * @param ret - The output array to be pushed into.
 */
function getUniqueMoves(levelMoves: LevelMovesWithSource, ret: LevelMovesWithSource): void {
  const uniqueMoves: MoveId[] = [];
  for (const lm of levelMoves) {
    if (!uniqueMoves.some(m => m === lm[1])) {
      uniqueMoves.push(lm[1]);
      ret.push(lm);
    }
  }
}

/**
 * Returns the non-fusion counterpart for a learnable move source.
 * Fusion sources are odd and directly follow their base counterpart.
 * @param source - The learnable move source to get the base source of
 * @returns The base learnable move source
 */
export function getBaseLearnableMoveSource(source: LearnableMoveSource): LearnableMoveSource {
  return (source - (source % 2)) as LearnableMoveSource;
}

/**
 * Helper method for {@linkcode getLevelMoves}
 *
 * Filters out moves not within the correct level range(s) and duplicates.
 * Sorts the moves first by level, then by source.
 * @param levelMoves - The list of level moves to filter and sort
 * @param startingLevel - Don't include moves below this level
 * @param includeEvolutionMoves - (Default `false`) Whether to include evolution moves
 * @param includeRelearnerMoves - (Default `false`) Whether to include moves that would require a relearner. Note the move relearner inherently allows evolution moves
 * @returns A filtered and sorted list of level moves
 */
function filterAndSortLevelMoves(
  context: LevelMoveContext,
  levelMoves: LevelMovesWithSource,
  includeEvolutionMoves = false,
  includeRelearnerMoves = false,
): LevelMovesWithSource {
  levelMoves.sort(([lvlA, , sourceA], [lvlB, , sourceB]) => {
    if (lvlA !== lvlB) {
      return lvlA > lvlB ? 1 : -1;
    }

    return getBaseLearnableMoveSource(sourceA) - getBaseLearnableMoveSource(sourceB);
  });

  // A set of moves the species gets by level, but are above the current level
  const levelMovesAboveCurrentLevel = new Set(
    levelMoves
      .filter(lm => getBaseLearnableMoveSource(lm[2]) === LearnableMoveSource.LEVEL && lm[0] > context.level)
      .map(lm => lm[1]),
  );

  // A set of moves the species learns by level.
  // Only includes level moves it can already learn.
  // Used to prefer showing a move as level rather than showing as a prevo/evo move
  const ownMoves = new Set(
    levelMoves
      .filter(lm => getBaseLearnableMoveSource(lm[2]) === LearnableMoveSource.LEVEL && lm[0] <= context.level)
      .map(lm => lm[1]),
  );

  /*
   * Filter out moves not within the correct level range(s)
   * Includes moves below startingLevel, or of specifically level 0 if
   * includeRelearnerMoves or includeEvolutionMoves are true respectively
   */
  levelMoves = levelMoves.filter(lm => {
    const [level, move, source] = lm;
    const isRelearner = level < context.startingLevel;
    const allowedEvolutionMove = level === 0 && includeEvolutionMoves;
    const isLevelMoveSource = getBaseLearnableMoveSource(source) === LearnableMoveSource.LEVEL;
    const isOwnMoveFromNonLevelSource = ownMoves.has(move) && !isLevelMoveSource;
    const isLockedPrevoMove =
      levelMovesAboveCurrentLevel.has(move)
      && (source === LearnableMoveSource.PREVO || source === LearnableMoveSource.FUSION_PREVO);

    return (
      !(level > context.level)
      && !isOwnMoveFromNonLevelSource
      && !isLockedPrevoMove
      && (includeRelearnerMoves || !isRelearner || allowedEvolutionMove)
    );
  });

  const ret: LevelMovesWithSource = [];
  /*
   * This must be done AFTER filtering by level, else if the same move shows up
   * in levelMoves multiple times all but the lowest level one will be skipped.
   * This causes problems when there are intentional duplicates (i.e. Smeargle with Sketch)
   */
  if (context.includeDuplicates) {
    ret.push(...levelMoves);
  } else {
    getUniqueMoves(levelMoves, ret);
  }

  return ret;
}

/**
 * Get all level moves the species form can learn
 * @param context - Basic information about the Pokemon to get the level moves for
 * @param includeEvolutionMoves - (Default: false) Whether to include evolution moves
 * @param includePrevolutionMoves - (Default: false) Whether to include moves from prevolutions
 * @param includeRelearnerMoves - (Default: false) Whether to include moves that would require a relearner. Note the move relearner inherently allows evolution moves
 * @param learnSituation - (Default: LearnMoveSituation.MISC) The situation in which the moves are being learned
 * @returns An array of level, moveid and source tuples, sorted by level and source.
 */
export function getLevelMoves(
  context: LevelMoveContext,
  includeEvolutionMoves = false,
  includePrevolutionMoves = false,
  includeRelearnerMoves = false,
  learnSituation: LearnMoveSituation = LearnMoveSituation.MISC,
): LevelMovesWithSource {
  const levelMoves: LevelMovesWithSource = [];
  const isFusion = context.fusionSpeciesForm !== undefined;
  if (includeRelearnerMoves) {
    // Relearner moves inherently allow evolution moves
    // Setting this to ture ensures the correct source is used
    includeEvolutionMoves = true;
  }
  if (learnSituation === LearnMoveSituation.EVOLUTION_FUSED && isFusion) {
    // For fusion evolutions, get ONLY the moves of the component mon that evolved
    levelMoves.push(...getRegularLevelMoves(context, includeEvolutionMoves, includeRelearnerMoves, true));
  } else if (includePrevolutionMoves) {
    levelMoves.push(...getPrevolutionMoves(context, includeEvolutionMoves, includeRelearnerMoves));
  } else {
    levelMoves.push(...getRegularLevelMoves(context, includeEvolutionMoves, includeRelearnerMoves));
  }

  if (isFusion && learnSituation !== LearnMoveSituation.EVOLUTION_FUSED_BASE) {
    const methodFunc = includePrevolutionMoves ? getPrevolutionMoves : getRegularLevelMoves;
    levelMoves.push(...methodFunc(context, includeEvolutionMoves, includeRelearnerMoves, true));
  }

  return filterAndSortLevelMoves(context, levelMoves, includeEvolutionMoves, includeRelearnerMoves);
}
