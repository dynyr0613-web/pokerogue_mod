import { globalScene } from "#app/global-scene";
import { speciesDataRegistry } from "#app/global-species-data-registry";
import type { SpeciesFormEvolution } from "#balance/pokemon-evolutions";
import type { PokemonSpecies } from "#data/pokemon-species";
import { EvoLevelThresholdKind } from "#enums/evo-level-threshold-kind";
import { PartyMemberStrength } from "#enums/party-member-strength";
import type { SpeciesId } from "#enums/species-id";
import { randSeedIntRange, randSeedItem } from "#utils/common";

/**
 * Controls the maximum level difference that a Pokémon spawned with
 * {@linkcode EvoLevelThresholdKind.NORMAL} is allowed to remain unevolved.
 */
const NORMAL_TRAINER_LEVEL_DIFF_PERCENT = 1.1;
/**
 * Controls the maximum level difference that a Pokémon spawned with
 * {@linkcode EvoLevelThresholdKind.WILD} is allowed to remain unevolved.
 */
const WILD_LEVEL_DIFF_PERCENT = 1.2;
/**
 * Controls the maximum level difference that a Pokémon spawned with
 * {@linkcode EvoLevelThresholdKind.STRONG} is allowed to remain unevolved.
 */
const STRONG_LEVEL_DIFF_PERCENT = 1;

/**
 * Local fork (2026-11-08): from this Endless wave on, a trainer's Pokémon also takes every evolution that has no level
 * of its own (stone, trade, friendship, held item or another condition), whatever its delay threshold. Trainer levels
 * there are 63 and up, and the largest delay threshold in the data is 85 (Normal) / 100 (Wild).
 */
export const ENDLESS_TRAINER_FULL_EVOLUTION_WAVE = 100;

/**
 * Local fork (2026-11-08), the user: Endless trainers should not keep weak, unevolved Pokémon. Whether the species being
 * generated belongs to a trainer in Endless or Spliced Endless, where {@linkcode getEndlessTrainerEvoLevel} applies.
 * It needs the current battle's trainer, so Daily starters and wild Pokémon keep the stock rules.
 */
export function isEndlessTrainerSpeciesGen(): boolean {
  return !!globalScene.gameMode?.isEndless && !!globalScene.currentBattle?.trainer;
}

/**
 * Local fork (2026-11-08): the level from which an Endless trainer's Pokémon always takes an evolution step.
 * - A level evolution (`levelReq > 1`, conditions such as time of day ignored like the stock code does): its own level,
 *   with no random delay and no extra delay threshold.
 * - Any other evolution (stone, trade, friendship, item, other condition): any level from Endless wave
 *   {@linkcode ENDLESS_TRAINER_FULL_EVOLUTION_WAVE} on; before that it keeps the stock threshold.
 * @param levelReq - The evolution's own level requirement
 * @returns The level, or `undefined` when the step keeps the stock rule
 */
function getEndlessTrainerEvoLevel(levelReq: number): number | undefined {
  if (levelReq > 1) {
    return levelReq;
  }
  if ((globalScene.currentBattle?.waveIndex ?? 0) >= ENDLESS_TRAINER_FULL_EVOLUTION_WAVE) {
    return 1;
  }
  return undefined;
}

/**
 * Get the evolution threshold for the given evolution, or `0` for ineligible
 * @param ev - The evolution to consider
 * @param level - The level of the Pokémon
 * @param evolutionPool - The pool of evolutions to add to
 * @returns The level threshold required for the evolution, or `0` if not eligible
 */
function calcEvoChance(ev: SpeciesFormEvolution, level: number, encounterKind: EvoLevelThresholdKind): number {
  /** The level requirement based on the trainer type */
  const levelThreshold = Math.max(ev.level, ev.evoLevelThreshold?.[encounterKind] ?? 0);
  // Disallow evolution if the level is below its required threshold.
  if (level < ev.level || level < levelThreshold) {
    return 0;
  }
  return levelThreshold;
}

/**
 * If the Pokémon is below the required level threshold for its species, return the
 * first pre-evolution that meets the level requirement.
 * @param species - The species to consider
 * @param level - The level the Pokémon will be
 * @param encounterKind - The kind of evolution threshold to use
 * @returns The speciesId of the forced prevolution, or `null` if none is required.
 *
 * @remarks
 * Forced prevolutions do *not* apply the randomness factor. That is, if the
 * Pokémon evolves multiple times and its level is currently near (but above)
 * the level requirement for its stage 2, it will always return the stage 2
 * evolution. For example, if the provided species is Venusaur, but the spawn
 * level is level 17 (bulbasaur evolves at 16), then it will *always* return
 * Ivysaur with *no* chance for Bulbasaur.
 *
 * @privateRemarks
 * The above limitation can be overcome, though requires more complex logic.
 *
 */
function getRequiredPrevo(
  species: PokemonSpecies,
  level: number,
  encounterKind: EvoLevelThresholdKind,
  endlessTrainer = false,
): SpeciesId | null {
  // Get the prevolution levels for this species.
  const prevolutionLevels = species.getPrevolutionLevels(true);

  // Return the base species if it's below the prevolution level threshold
  // Go in reverse order to go from earlier in evolution line to later
  // NOTE: This will *not* apply the randomness factor.
  for (let pl = prevolutionLevels.length - 1; pl >= 0; pl--) {
    const [prevoSpecies, levelReq, evoThreshold] = prevolutionLevels[pl];
    const threshold = evoThreshold?.[encounterKind] ?? levelReq;
    let req = levelReq === 1 ? threshold : Math.min(levelReq, threshold);
    // Local fork (2026-11-08): an Endless trainer keeps an evolved species once the Endless rule allows the step, and
    // the rule is never stricter than the stock one
    if (endlessTrainer) {
      req = Math.min(req, getEndlessTrainerEvoLevel(levelReq) ?? req);
    }
    if (level < req) {
      return prevoSpecies;
    }
  }

  return null;
}

/**
 * Determine the species of an enemy Pokémon, based on various factors.
 *
 * @param species - The species to consider
 * @param level - The level the Pokémon will be
 * @param allowEvolving - Whether to allow evolution; default `false`
 * @param forTrainer - Whether the Pokémon is for a trainer; default `false`
 * @param strength - The strength of the party member; default {@linkcode PartyMemberStrength.WEAKER | Weaker}
 * @param encounterKind - The kind of evolution threshold to use; default {@linkcode EvoLevelThresholdKind.NORMAL | Normal} for trainers, {@linkcode EvoLevelThresholdKind.WILD | Wild} otherwise
 * @param tryForcePrevo - Whether to skip checking for prevolutions. Should only be `false` when invoked recursively; default `true`
 *
 * @remarks
 * Passing a species with split evolutions will randomly choose one of its
 * evolutions based on its level. Passing an evolved species _may_ allow a
 * pre-evolution to be chosen, based on its level, though if the pre-evolution
 * has split evolutions, it will always choose from the species line that has
 * the passed species
 *
 * @see {@link calcEvoChance}
 */
export function determineEnemySpecies(
  species: PokemonSpecies,
  level: number,
  allowEvolving = false,
  forTrainer = false,
  strength: PartyMemberStrength = PartyMemberStrength.WEAKER,
  encounterKind: EvoLevelThresholdKind = forTrainer ? EvoLevelThresholdKind.NORMAL : EvoLevelThresholdKind.WILD,
  tryForcePrevo = true,
): SpeciesId {
  // Local fork (2026-11-08): Endless and Spliced Endless trainers evolve fully for their level (getEndlessTrainerEvoLevel)
  const endlessTrainer = forTrainer && isEndlessTrainerSpeciesGen();
  const requiredPrevo =
    tryForcePrevo
    && speciesDataRegistry.hasPrevolution(species.speciesId)
    && getRequiredPrevo(species, level, encounterKind, endlessTrainer);
  if (requiredPrevo) {
    return requiredPrevo;
  }
  let evolutions = speciesDataRegistry.getEvolutions(species.speciesId);
  if (
    // If evolutions shouldn't happen, add more cases here :)
    !allowEvolving
    || evolutions.length <= 0
    || (globalScene.currentBattle?.waveIndex === 20
      && globalScene.gameMode.isClassic
      && globalScene.currentBattle.trainer)
  ) {
    return species.speciesId;
  }

  // If this is for a trainer with a specialty type, and there's a possible evo with that type, filter for it
  if (globalScene.currentBattle?.trainer && globalScene.currentBattle.trainer?.config.hasSpecialtyType()) {
    const specialtyType = globalScene.currentBattle.trainer.config.specialtyType;
    const filteredEvos = evolutions.filter(e => {
      return speciesDataRegistry.getPokemonSpeciesForm(e.speciesId, e.evoFormKey ?? 0).isOfType(specialtyType);
    });
    if (filteredEvos.length > 0 && filteredEvos.length < evolutions.length) {
      evolutions = filteredEvos;
    }
  }

  // Local fork (2026-11-08): the third value marks a step an Endless trainer must take (getEndlessTrainerEvoLevel)
  const evoPool: [number, SpeciesId, boolean][] = [];

  for (const e of evolutions) {
    const threshold = calcEvoChance(e, level, encounterKind);
    const endlessLevel = endlessTrainer ? getEndlessTrainerEvoLevel(e.level) : undefined;
    const forced = endlessLevel != null && level >= endlessLevel;
    if (threshold > 0) {
      evoPool.push([threshold, e.speciesId, forced]);
    } else if (forced) {
      evoPool.push([Math.max(e.level, 1), e.speciesId, true]);
    }
  }
  if (evoPool.length === 0) {
    return species.speciesId;
  }
  const [choice, evoSpecies, forcedChoice] = randSeedItem(evoPool);
  // Add a linearly scaling random factor to the level requirement
  // The higher the level, the more likely it is to evolve.
  // If the mon is N levels above the requirement, it has a (N - Multiplier*Requirement) / (Multiplier * Requirement) chance to evolve.
  // As an example, if the pokemon evolves at level 50, and the mon is currently level 54, and the multiplier is 0.2,
  // Then it is guaranteed to evolve by level 60, and has a 10% chance to be evolved
  let multiplier = 1;
  switch (encounterKind) {
    case EvoLevelThresholdKind.STRONG:
      multiplier = STRONG_LEVEL_DIFF_PERCENT;
      break;
    case EvoLevelThresholdKind.NORMAL:
      multiplier = NORMAL_TRAINER_LEVEL_DIFF_PERCENT;
      break;
    case EvoLevelThresholdKind.WILD:
      multiplier = WILD_LEVEL_DIFF_PERCENT;
      break;
  }

  const randomLevel = randSeedIntRange(choice, Math.round(choice * multiplier));
  // Local fork (2026-11-08): the roll is still made, so the RNG sequence only moves where the Endless rule decides
  let nextSpecies: SpeciesId | null = randomLevel <= level || forcedChoice ? evoSpecies : null;
  if (nextSpecies == null) {
    // Local fork (2026-11-08): the picked branch missed its roll, but an Endless trainer must take another branch
    const forcedEvos = evoPool.filter(([, , forced]) => forced);
    if (forcedEvos.length > 0) {
      nextSpecies = (forcedEvos.length === 1 ? forcedEvos[0] : randSeedItem(forcedEvos))[1];
    }
  }
  if (nextSpecies != null) {
    return determineEnemySpecies(
      speciesDataRegistry.getSpecies(nextSpecies),
      level,
      true,
      forTrainer,
      strength,
      encounterKind,
      false,
    );
  }
  return species.speciesId;
}

/**
 * Local fork (2026-11-08): the species a fusion tail of an Endless or Spliced Endless trainer's Pokémon grows into at
 * `level`. Tails are rolled as is (only matching the head's evolution stage, or any legendary for a legendary head), so
 * a tail can still evolve; it goes through the same rule as the head, without forcing a prevolution.
 * @param species - The rolled tail
 * @param level - The Pokémon's level
 * @returns The tail to use; `species` itself outside an Endless trainer battle
 */
export function getEndlessTrainerFusionSpecies(species: PokemonSpecies, level: number): PokemonSpecies {
  if (!isEndlessTrainerSpeciesGen()) {
    return species;
  }
  const speciesId = determineEnemySpecies(
    species,
    level,
    true,
    true,
    PartyMemberStrength.AVERAGE,
    EvoLevelThresholdKind.NORMAL,
    false,
  );
  return speciesId === species.speciesId ? species : speciesDataRegistry.getSpecies(speciesId);
}
