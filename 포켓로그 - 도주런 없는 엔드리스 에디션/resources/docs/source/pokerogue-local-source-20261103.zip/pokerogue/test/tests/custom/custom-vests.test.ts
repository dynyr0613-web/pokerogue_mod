import { modifierTypes } from "#data/data-lists";
import { AbilityId } from "#enums/ability-id";
import { ModifierPoolType } from "#enums/modifier-pool-type";
import { ModifierTier } from "#enums/modifier-tier";
import { MoveId } from "#enums/move-id";
import { SpeciesId } from "#enums/species-id";
import { Stat } from "#enums/stat";
import type { Pokemon } from "#field/pokemon";
import { AssaultVestModifier, BulletproofVestModifier } from "#modifiers/custom-held-items";
import type { PokemonHeldItemModifier } from "#modifiers/modifier";
import * as Modifier from "#modifiers/modifier";
import { GameManager } from "#test/framework/game-manager";
import type { WeightedModifierTypeWeightFunc } from "#types/modifier-types";
import { getModifierPoolForType } from "#utils/modifier-utils";
import Phaser from "phaser";
import { beforeAll, beforeEach, describe, expect, it } from "vitest";

describe("Custom held items - vests", () => {
  let phaserGame: Phaser.Game;
  let game: GameManager;

  beforeAll(() => {
    phaserGame = new Phaser.Game({ type: Phaser.HEADLESS });
  });

  beforeEach(() => {
    game = new GameManager(phaserGame);
    game.override
      .criticalHits(false)
      .battleStyle("single")
      .enemySpecies(SpeciesId.RATTATA)
      .enemyAbility(AbilityId.BALL_FETCH)
      .enemyMoveset(MoveId.SPLASH)
      .ability(AbilityId.BALL_FETCH)
      .moveset([MoveId.SPLASH]);
  });

  const vests = [
    { name: "ASSAULT_VEST", cls: AssaultVestModifier, stat: Stat.SPDEF, other: Stat.DEF },
    { name: "BULLETPROOF_VEST", cls: BulletproofVestModifier, stat: Stat.DEF, other: Stat.SPDEF },
  ] as const;

  /** A fresh vest for `pokemon`, with its type id set the way `overrideHeldItems` and the reward pools do. */
  function newVest(name: (typeof vests)[number]["name"], pokemon: Pokemon): PokemonHeldItemModifier {
    return modifierTypes[name]().withIdFromFunc(modifierTypes[name]).newModifier(pokemon) as PokemonHeldItemModifier;
  }

  describe.each(vests)("$name", ({ name, cls, stat, other }) => {
    it("multiplies only its own stat by 1.5", async () => {
      game.override.startingHeldItems([{ name }]);
      await game.classicMode.startBattle(SpeciesId.SNORLAX);
      const snorlax = game.field.getPlayerPokemon();

      const vest = snorlax.getHeldItems().find(m => m instanceof cls);
      expect(vest).toBeDefined();
      expect(vest!.stackCount).toBe(1);
      expect(vest!.type.id).toBe(name);
      expect(vest!.isTransferable).toBe(true);

      const base = snorlax.getEffectiveStat(stat, { ignoreHeldItems: true });
      expect(base).toBe(snorlax.getStat(stat, false));
      expect(snorlax.getEffectiveStat(stat)).toBe(Math.floor(base * 1.5));
      for (const untouched of [other, Stat.ATK, Stat.SPATK, Stat.SPD] as const) {
        expect(snorlax.getEffectiveStat(untouched)).toBe(
          snorlax.getEffectiveStat(untouched, { ignoreHeldItems: true }),
        );
      }
    });

    it("is held at most once per Pokemon", async () => {
      game.override.startingHeldItems([{ name }]);
      await game.classicMode.startBattle(SpeciesId.SNORLAX, SpeciesId.FEEBAS);
      const [snorlax, feebas] = game.scene.getPlayerParty();
      const vest = snorlax.getHeldItems().find(m => m instanceof cls)!;
      expect(vest.getMaxHeldItemCount(snorlax)).toBe(1);
      expect(vest.getMaxStackCount()).toBe(1);

      // A second copy handed to the same holder merges into the existing one and is refused
      // (`addModifier` only reports `true` for consumables, so check the held items instead)
      game.scene.addModifier(newVest(name, snorlax), true);
      expect(vest.stackCount).toBe(1);
      expect(snorlax.getHeldItems().filter(m => m instanceof cls)).toHaveLength(1);

      // Feebas gets its own; moving it onto Snorlax, who already holds one, is refused
      const feebasVest = newVest(name, feebas);
      game.scene.addModifier(feebasVest, true);
      expect(feebas.getHeldItems().filter(m => m instanceof cls)).toHaveLength(1);
      expect(game.scene.tryTransferHeldItemModifier(feebasVest, snorlax, false)).toBe(false);
      expect(vest.stackCount).toBe(1);
      expect(feebasVest.stackCount).toBe(1);
      expect(feebas.getHeldItems().filter(m => m instanceof cls)).toHaveLength(1);

      // ...but a holder without one takes it
      game.scene.removeModifier(vest);
      expect(game.scene.tryTransferHeldItemModifier(feebasVest, snorlax, false)).toBe(true);
      expect(feebas.getHeldItems().filter(m => m instanceof cls)).toHaveLength(0);
      expect(snorlax.getHeldItems().filter(m => m instanceof cls)).toHaveLength(1);
    });

    it("survives the session save round trip with only the holder's id as args", async () => {
      game.override.startingHeldItems([{ name }]);
      await game.classicMode.startBattle(SpeciesId.SNORLAX);
      const snorlax = game.field.getPlayerPokemon();
      const vest = snorlax.getHeldItems().find(m => m instanceof cls)!;
      expect(vest.getArgs()).toEqual([snorlax.id]);
      expect(vest.clone()).toBeInstanceOf(cls);
      expect(vest.clone().getArgs()).toEqual([snorlax.id]);

      const { gameData } = game.scene;
      const json = JSON.stringify(gameData.getSessionSaveData(), (_, v) => (typeof v === "bigint" ? v.toString() : v));
      const saved = gameData.parseSessionData(json).modifiers.find(m => m.typeId === name)!;
      expect(saved.className).toBe(cls.name);
      expect(saved.args).toEqual([snorlax.id]);
      expect(saved.stackCount).toBe(1);

      // `GameData.loadSession` looks the class up by name in the `modifier.ts` namespace, where ours is absent
      expect(Modifier[saved.className]).toBeUndefined();
      const restored = saved.toModifier(Modifier[saved.className])!;
      expect(restored).toBeInstanceOf(cls);
      expect(restored.getArgs()).toEqual([snorlax.id]);
      expect(restored.stackCount).toBe(1);
      expect(restored.type.id).toBe(name);
      expect(restored.match(vest)).toBe(true);

      // An over-stacked save is clamped back to one on load
      saved.stackCount = 3;
      expect(saved.toModifier(Modifier[saved.className])!.stackCount).toBe(1);
    });
  });

  it("the two vests are different items that can be held together", async () => {
    game.override.startingHeldItems([{ name: "ASSAULT_VEST" }]);
    await game.classicMode.startBattle(SpeciesId.SNORLAX);
    const snorlax = game.field.getPlayerPokemon();
    const assault = snorlax.getHeldItems().find(m => m instanceof AssaultVestModifier)!;
    const bulletproof = newVest("BULLETPROOF_VEST", snorlax);

    expect(assault.matchType(bulletproof)).toBe(false);
    expect(bulletproof.matchType(assault)).toBe(false);
    game.scene.addModifier(bulletproof, true);
    expect(snorlax.getHeldItems().filter(m => m instanceof AssaultVestModifier)).toHaveLength(1);
    expect(snorlax.getHeldItems().filter(m => m instanceof BulletproofVestModifier)).toHaveLength(1);

    const def = snorlax.getEffectiveStat(Stat.DEF, { ignoreHeldItems: true });
    const spDef = snorlax.getEffectiveStat(Stat.SPDEF, { ignoreHeldItems: true });
    expect(snorlax.getEffectiveStat(Stat.DEF)).toBe(Math.floor(def * 1.5));
    expect(snorlax.getEffectiveStat(Stat.SPDEF)).toBe(Math.floor(spDef * 1.5));
  });

  it("sits in the MASTER tier of the player pool at weight 12 until every party member holds one", async () => {
    game.override.startingHeldItems([{ name: "ASSAULT_VEST" }]);
    await game.classicMode.startBattle(SpeciesId.SNORLAX, SpeciesId.FEEBAS);
    const party = game.scene.getPlayerParty();
    const master = getModifierPoolForType(ModifierPoolType.PLAYER)[ModifierTier.MASTER];

    for (const { name, cls } of vests) {
      const entry = master.find(w => w.modifierType.id === name)!;
      expect(entry).toBeDefined();
      expect(entry.modifierType.tier).toBe(ModifierTier.MASTER);
      expect(entry.maxWeight).toBe(12);
      const weight = entry.weight as WeightedModifierTypeWeightFunc;

      // Snorlax holds an Assault Vest, Feebas holds nothing: both vests are still on offer
      expect(weight(party, 0)).toBe(12);
      game.scene.addModifier(entry.modifierType.newModifier(party[1]), true);
      if (cls === AssaultVestModifier) {
        expect(weight(party, 0)).toBe(0);
      } else {
        // only Feebas has the Bulletproof Vest so far
        expect(weight(party, 0)).toBe(12);
        game.scene.addModifier(entry.modifierType.newModifier(party[0]), true);
        expect(weight(party, 0)).toBe(0);
      }
    }
  });
});
