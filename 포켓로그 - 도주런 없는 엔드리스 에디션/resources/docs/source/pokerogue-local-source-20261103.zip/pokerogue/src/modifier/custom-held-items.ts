/**
 * Held items added by this local fork (2026-11-02).
 *
 * They live outside `modifier.ts` so that file stays close to upstream. Session saves look modifier
 * classes up by name in the `modifier.ts` module namespace, so `ModifierData.toModifier` falls back to
 * {@linkcode getCustomModifierClass} for the classes defined here.
 */

import { Stat } from "#enums/stat";
import type { Pokemon } from "#field/pokemon";
import type { Modifier, PersistentModifier } from "#modifiers/modifier";
import { StatBoosterModifier } from "#modifiers/modifier";
import type { ModifierType } from "#modifiers/modifier-type";

/**
 * Assault Vest (돌격조끼): the holder's Sp. Def is multiplied by 1.5. Unlike the main-series item
 * it does not restrict the holder's moves. One per Pokémon, transferable.
 */
export class AssaultVestModifier extends StatBoosterModifier {
  constructor(type: ModifierType, pokemonId: number, stackCount?: number) {
    super(type, pokemonId, [Stat.SPDEF], 1.5, stackCount);
  }

  override matchType(modifier: Modifier): boolean {
    return modifier instanceof AssaultVestModifier;
  }

  override clone(): AssaultVestModifier {
    return new AssaultVestModifier(this.type, this.pokemonId, this.stackCount);
  }

  /** Only the holder's id is saved; the stat and multiplier are fixed by the class (see the constructor). */
  override getArgs(): any[] {
    return [this.pokemonId];
  }

  override getMaxHeldItemCount(_pokemon?: Pokemon): number {
    return 1;
  }
}

/**
 * Bulletproof Vest (방탄조끼): the holder's Defense is multiplied by 1.5. One per Pokémon, transferable.
 */
export class BulletproofVestModifier extends StatBoosterModifier {
  constructor(type: ModifierType, pokemonId: number, stackCount?: number) {
    super(type, pokemonId, [Stat.DEF], 1.5, stackCount);
  }

  override matchType(modifier: Modifier): boolean {
    return modifier instanceof BulletproofVestModifier;
  }

  override clone(): BulletproofVestModifier {
    return new BulletproofVestModifier(this.type, this.pokemonId, this.stackCount);
  }

  /** Only the holder's id is saved; the stat and multiplier are fixed by the class (see the constructor). */
  override getArgs(): any[] {
    return [this.pokemonId];
  }

  override getMaxHeldItemCount(_pokemon?: Pokemon): number {
    return 1;
  }
}

const customModifierClasses: Readonly<Record<string, new (...args: any[]) => PersistentModifier>> = Object.freeze({
  AssaultVestModifier,
  BulletproofVestModifier,
});

/**
 * Look up one of this file's modifier classes by its class name, the way save data refers to it
 * (`ModifierData.className`).
 * @param className - The constructor name stored in the session save
 * @returns The class, or `undefined` when the name is not one of ours
 */
export function getCustomModifierClass(className: string): (new (...args: any[]) => PersistentModifier) | undefined {
  return customModifierClasses[className];
}
